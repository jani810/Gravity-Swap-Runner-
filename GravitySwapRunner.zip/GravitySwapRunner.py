import pygame
import random

pygame.init()

WIDTH, HEIGHT = 800, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

gravity = 1
player_jump = -15
player_y_velocity = 0

player = pygame.Rect(100, HEIGHT // 2, 40, 40)
platforms = [pygame.Rect(x, HEIGHT - 40, 80, 20) for x in range(0, WIDTH, 150)]
coins = [pygame.Rect(random.randint(200, WIDTH), random.randint(50, HEIGHT - 50), 20, 20) for _ in range(10)]
score = 0
running = True
flipped = False

while running:
    screen.fill((30, 30, 30))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                flipped = not flipped
                gravity *= -1
                player.y += gravity * 10

    player_y_velocity += gravity
    player.y += player_y_velocity
    if flipped:
        if player.y <= 0:
            player.y = 0
            player_y_velocity = 0
    else:
        if player.y >= HEIGHT - player.height:
            player.y = HEIGHT - player.height
            player_y_velocity = 0

    for platform in platforms:
        pygame.draw.rect(screen, (200, 50, 50), platform)
        platform.x -= 5
        if platform.right < 0:
            platform.x = WIDTH

    for coin in coins[:]:
        pygame.draw.ellipse(screen, (255, 223, 0), coin)
        coin.x -= 5
        if coin.right < 0:
            coin.x = WIDTH
            coin.y = random.randint(50, HEIGHT - 50)
        if player.colliderect(coin):
            score += 1
            coins.remove(coin)
            coins.append(pygame.Rect(random.randint(WIDTH, WIDTH + 100), random.randint(50, HEIGHT - 50), 20, 20))

    pygame.draw.rect(screen, (50, 150, 255), player)
    score_text = pygame.font.Font(None, 36).render(f"Score: {score}", True, (255, 255, 255))
    screen.blit(score_text, (10, 10))
    pygame.display.flip()
    clock.tick(30)

pygame.quit()
